// Java Program to Create a Method with 2 Parameters and without Return Type

class Addition{
	
	static void printSum(int x, int y){
		System.out.println("Sun is: " + (x+y));
	}

}
class Problem14{

	public static void main(String[] args){
		
		Addition.printSum(15,20);
	}
}


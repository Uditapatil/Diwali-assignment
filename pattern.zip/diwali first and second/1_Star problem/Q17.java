class Q17
{	
	
	
	public static void main(String args[])
	{
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=i;j++)
			{
			System.out.print("* ");
			
			}
			System.out.println();
			System.out.println();
			
		}
		
		
		for(int i=4;i>=1;i--)
		{
			for(int j=1;j<=i;j++)
			{
			System.out.print("* ");
			
			
			}
		System.out.println();
		System.out.println();
		}
	
	}
}

/*
E:\java\notepadfilesofjava\diwali assignment\Solution\Star problem>java Q17
*

* *

* * *

* * * *

* * * * *

* * * *

* * *

* *

*
*/
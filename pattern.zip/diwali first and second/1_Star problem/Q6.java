class Q6
{
	public static void main(String args[])
	{
		for(int i=1;i<=5;i++)
		{	
			for(int l =i; l>=1;l-- )
			{
				System.out.print(l+" ");
			}
				System.out.println();
		}
	}
}	

/*
E:\java\notepadfilesofjava\diwali assignment\Solution\Star problem>java Q6
1
2 1
3 2 1
4 3 2 1
5 4 3 2 1
*/